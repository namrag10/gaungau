package mainProcesses;

public interface main {
    public output view();
}
