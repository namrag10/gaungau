package Structures.Functions;

import java.util.ArrayList;
import java.util.Stack;

import ErrorHandle.Error;
import Structures.Meta.Condition;
import Structures.Meta.LineMeta;
import Structures.Meta.Struc;

public class Function extends Struc {


	public Condition condition;
	public Stack < Struc > block = new Stack < Struc > ();
	private builtinFunctionality functionality;
	private int startingILine = 0;
	// private struct type;

	public Function(LineMeta rawStatement) {
		raw = rawStatement.lineText;
		lineNumber = rawStatement.lineNumber;
	}

	@Override
	public boolean parse(int crntILine) {
		startingILine = crntILine;
		condition = new Condition(extractCondition(), lineNumber);
		boolean requiresCondition = true;


// open bracket problem
		switch (getType()) {
			case "if":
				functionality = new ifFunc(startingILine, condition, hasElse);
				break;
			case "while":
				functionality = new whileFunc(startingILine, condition);
				break;
			case "exit":
				requiresCondition = false;
				functionality = new exitFunc(startingILine, condition);
				break;
			case "print":
				requiresCondition = false;
				functionality = new printFunc(startingILine, condition, lineNumber);				
				break;
			case "raw":
				requiresCondition = false;
				functionality = new rawStatement(startingILine, condition, lineNumber);				
				break;
			case "else":
				requiresCondition = false;
				functionality = new elseStatement(startingILine);
				break;
			default:
				requiresCondition = false;
				functionality = new customFunction(startingILine, condition, lineNumber);
				System.out.println(raw + " NEW FUNCTION - noted but not implemented");
				break;
		}

		if(!functionality.validUse)
			return false;
		
		// Sort out the condition if needed
		if (requiresCondition) {
			if(raw.indexOf(")") == -1){
				Error.syntaxError("No close bracket", lineNumber);
				return false;
			}

			if (condition.getRaw() == null) {
				Error.syntaxError("No condition found", lineNumber);
				return false;
			}

			if (!functionality.generateCondition())
				return false;
		}
		crntILine += functionality.preInstructionCount();

		// Discover structures in block
		// Hot recursion going on here
		for (Struc structure: block) {
			if (!structure.parse(crntILine))
				return false;
			crntILine += structure.instructionCount();
		}

		functionality.closeHandle(crntILine);
		crntILine += functionality.postBlock.size();
		instructionsInBlock += crntILine - startingILine;
		return true;
	}

	// Adds a statement to the block
	public void addStatement(Struc line) {
		block.add(line);
	}

	private String extractCondition() {
		int bracketIndex = raw.indexOf("(");
		return (bracketIndex > -1) ? raw.substring(bracketIndex) : null;
	}


	// Sexy polymorphism going on here
	@Override
	public ArrayList < String > buildAndGetInstructions() {

		for (String string: functionality.preBlock)
			instructions.add(string);


		for (Struc structure: block)
			for (String string: structure.buildAndGetInstructions())
				instructions.add(string);


		for (String string: functionality.postBlock)
			instructions.add(string);

		return instructions;
	}
}